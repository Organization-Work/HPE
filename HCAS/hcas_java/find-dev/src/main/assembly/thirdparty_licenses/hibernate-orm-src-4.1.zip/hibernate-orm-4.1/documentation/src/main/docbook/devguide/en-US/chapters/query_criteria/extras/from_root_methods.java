<X> Root<X> from(Class<X>);

<X> Root<X> from(EntityType<X>)