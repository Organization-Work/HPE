Configuration cfg = ....;
new SchemaExport(cfg).create(false, true);